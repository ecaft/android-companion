package it.sephiroth.android.library.imagezoom.utils;

public interface IDisposable {

	void dispose();
}
